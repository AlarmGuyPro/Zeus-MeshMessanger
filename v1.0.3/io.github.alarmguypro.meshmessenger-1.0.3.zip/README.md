# Mesh Messenger for Zeus SDR

Read, send and reply to **Meshtastic** and **MeshCore** text messages from
inside Zeus, through LoRa nodes (such as a Heltec V4) on your Wi-Fi.

> Status: 1.0.1, built and bench-tested on real hardware — a Heltec V4 running
> MeshCore companion Wi-Fi firmware and another running Meshtastic — as well as
> against simulated nodes in the test suite. 0.4.1 is the version currently
> listed in the Zeus community catalog.

User help: [docs/help](docs/help/README.md), including an
[options reference](docs/help/options.md) that says what every setting does
and whether it transmits.


**Picking this up?** [docs/STATUS.md](docs/STATUS.md) says where the project
stands, what the bench looks like and what to do next.
[docs/ZEUS-PLUGIN-PLAYBOOK.md](docs/ZEUS-PLUGIN-PLAYBOOK.md) is what we learned
building and submitting it, written for the next Zeus feature rather than this
one.

## How it behaves

- One inbox for both networks. Every conversation shows a network badge
  (**MT** = Meshtastic, **MC** = MeshCore) and the node it belongs to.
- **A reply always goes out on the node and network the conversation came in
  on.** If that node is offline, the reply fails and is marked "Not sent". It
  is never re-sent on the other network.
- Starting a new message asks which node to send from.

## What it accesses

- **Network:** TCP connections to the mesh nodes you configure on your LAN.
- **Settings:** its own node list, in Zeus's per-feature settings store.

It does not read or change radio state, never keys the transmitter, and does
not touch PureSignal.

## Setting up a node

Give Zeus its own node: a LoRa board (such as a Heltec V4) on your Wi-Fi,
powered from the shack, that nothing else connects to. It becomes its own
station on your mesh, reaching it through your local repeaters, and it keeps
collecting messages while Zeus is closed. People message the station by the
node's name, so pick a clear one such as `<callsign> Shack`.

Keep the node and its antenna away from your HF antenna and feedline: strong
HF transmit signals can overload or damage it, and its Wi-Fi and switching
noise can show up in the SDR. An external antenna mounted a little way from
the station helps both ways.


Flash the node with Wi-Fi-enabled firmware and join it to the same network as
the Zeus computer:

- **Meshtastic:** enable Wi-Fi in the node's network settings. Zeus connects to
  TCP port 4403.
- **MeshCore:** use the companion-radio Wi-Fi build for your board (for the
  Heltec V4: `heltec_v4_companion_radio_wifi`). MeshCore's Wi-Fi network name
  and password are set when the firmware is built, so you need a build made
  with your network's details. Zeus connects to TCP port 5000. A MeshCore node
  talks to one app at a time: connecting the phone app or meshcore-cli over
  Wi-Fi disconnects Zeus until you close them.

Then use **Add node → Scan** in the panel: Zeus finds the node on your
network (or on other VLANs you list) and remembers it, so no static IP is
needed. See [docs/DISCOVERY.md](docs/DISCOVERY.md).

## Building (developers)

Requirements: .NET 10 SDK (the exact version in `global.json`), PowerShell 7,
Node.js 22+.

```powershell
pwsh scripts/build-package.ps1
```

This builds the panel (`web/`), the backend (`src/MeshMessenger/`) and writes
`artifacts/io.github.alarmguypro.meshmessenger/io.github.alarmguypro.meshmessenger-<version>.zip`.
Install it in Zeus with **Features → Community → Install local feature**.

The version lives in `src/MeshMessenger/plugin.json` and nowhere else that
matters: the panel shows whatever version Zeus loaded from that manifest. Two
build files carry a copy (`MeshMessenger.csproj` and `web/package.json`), and
the build refuses to run if either disagrees with the manifest.

See [DESIGN.md](DESIGN.md) for the architecture and routing rules.

## License

GPL-3.0-or-later. See [LICENSE](LICENSE) and
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). `sdk/` is a vendored copy of
the public Zeus plugin contracts (GPL-2.0-or-later; see `sdk/UPSTREAM.md`).
