import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region src/api.ts
var BackendError = class extends Error {};
async function json(response) {
	const text = await response.text();
	let body = void 0;
	try {
		body = text ? JSON.parse(text) : void 0;
	} catch {
		body = void 0;
	}
	if (!response.ok) throw new BackendError(body && typeof body === "object" && "error" in body && typeof body.error === "string" ? body.error : `Backend returned ${response.status}`);
	return body;
}
var enc = encodeURIComponent;
function createClient(api) {
	const call = async (method, path, body) => json(await api.callBackend(method, path, body));
	return {
		status: () => call("GET", "/status"),
		peers: (nodeId) => call("GET", `/nodes/${enc(nodeId)}/peers`),
		addNode: (body) => call("POST", "/nodes", body),
		updateNode: (id, body) => call("PATCH", `/nodes/${enc(id)}`, body),
		removeNode: (id) => call("DELETE", `/nodes/${enc(id)}`),
		repairNode: (id) => call("POST", `/nodes/${enc(id)}/repair`),
		acceptMove: (id) => call("POST", `/nodes/${enc(id)}/move`),
		ignoreMove: (id) => call("DELETE", `/nodes/${enc(id)}/move`),
		saveSettings: (body) => call("PUT", "/settings", body),
		discovery: () => call("GET", "/discovery"),
		startScan: (ranges, mdns) => call("POST", "/discovery/scan", {
			ranges,
			mdns
		}),
		stopScan: () => call("DELETE", "/discovery/scan"),
		conversations: () => call("GET", "/conversations"),
		messages: (conversationId) => call("GET", `/conversations/${enc(conversationId)}/messages`),
		mute: (conversationId, muted) => api.callBackend("POST", `/conversations/${enc(conversationId)}/mute`, { muted }),
		reply: (conversationId, text) => call("POST", `/conversations/${enc(conversationId)}/reply`, { text }),
		start: (connectorId, kind, peer, text) => call("POST", "/conversations", {
			connectorId,
			kind,
			peer,
			text
		}),
		deleteConversation: (conversationId) => api.callBackend("DELETE", `/conversations/${enc(conversationId)}`),
		clearFailed: (conversationId) => call("POST", `/conversations/${enc(conversationId)}/clear-failed`),
		retry: (conversationId, messageId) => call("POST", `/conversations/${enc(conversationId)}/messages/${enc(messageId)}/retry`),
		refreshPeers: (nodeId) => call("POST", `/nodes/${enc(nodeId)}/refresh-peers`),
		announce: (nodeId, flood) => call("POST", `/nodes/${enc(nodeId)}/announce`, { flood }),
		removePeer: (nodeId, peerId) => call("DELETE", `/nodes/${enc(nodeId)}/peers/${enc(peerId)}`),
		setRecycleOldest: (nodeId, enabled) => call("POST", `/nodes/${enc(nodeId)}/recycle-oldest`, { enabled }),
		debug: () => call("GET", "/debug")
	};
}
var networkLabel = {
	meshtastic: "Meshtastic",
	meshcore: "MeshCore"
};
var networkShort = {
	meshtastic: "MT",
	meshcore: "MC"
};
function textLimit(node, kind) {
	return kind === "channel" ? node.maxChannelTextBytes : node.maxDirectTextBytes;
}
function utf8Length(text) {
	return new TextEncoder().encode(text).length;
}
function errorText(err) {
	return err instanceof Error ? err.message : "Something went wrong.";
}
function ago(iso) {
	if (!iso) return "—";
	const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1e3);
	if (s < 90) return "just now";
	if (s < 3600) return `${Math.round(s / 60)} min`;
	if (s < 86400) return `${Math.round(s / 3600)} h`;
	return `${Math.round(s / 86400)} d`;
}
//#endregion
//#region src/styles.ts
var ROOT = "io-github-alarmguypro-meshmessenger";
var cx = (name) => `${ROOT}__${name}`;
var r = `.${ROOT}`;
var e = (name) => `.${ROOT}__${name}`;
var css = `
${r} {
  container-type: inline-size;
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  overflow-y: auto;
  color: var(--fg-1);
  background: var(--bg-1);
  font-family: var(--font-sans);
  font-size: 13px;
}
${r} *, ${r} *::before, ${r} *::after { box-sizing: border-box; }
${e("nodes")} {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 8px;
  border-bottom: 1px solid var(--line);
  background: var(--bg-2);
}
${e("node")} {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 3px 8px;
  border: 1px solid var(--line);
  border-radius: var(--r-sm);
  background: var(--bg-1);
}
${e("node--connected")} { border-color: var(--ok); }
${e("node--error")} { border-color: var(--amber); }
${e("badge")} {
  display: inline-block;
  min-width: 2.4em;
  padding: 1px 5px;
  border: 1px solid var(--line-strong);
  border-radius: var(--r-xs);
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 600;
  text-align: center;
  color: var(--fg-0);
  background: var(--bg-3);
}
${e("muted")} { color: var(--fg-2); }
${e("body")} {
  display: grid;
  grid-template-columns: minmax(180px, 35%) 1fr;
  flex: 1;
  /* Short panels (or 200% zoom) scroll the whole panel rather than squeezing the thread to nothing. */
  min-height: 20em;
}
${e("list")} {
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  min-width: 0;
  border-right: 1px solid var(--line);
  margin: 0;
  padding: 0;
  list-style: none;
}
${e("item")} {
  display: block;
  width: 100%;
  min-height: 44px;
  padding: 8px;
  border: 0;
  border-bottom: 1px solid var(--line);
  border-left: 3px solid var(--bg-1);
  background: none;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
${e("item--selected")} { border-left-color: var(--accent); background: var(--bg-2); }
${e("item-top")} { display: flex; min-width: 0; align-items: center; gap: 6px; }
${e("item-title")} { flex: 1; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
${e("item-preview")} { display: block; margin-top: 2px; color: var(--fg-2); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
${e("unread")} {
  padding: 0 6px;
  border-radius: var(--r-lg);
  background: var(--accent);
  color: var(--bg-0);
  font-size: 11px;
  font-weight: 700;
}
${e("thread")} { display: flex; flex-direction: column; min-height: 0; }
${e("thread-head")} {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px;
  border-bottom: 1px solid var(--line);
  background: var(--panel-top);
}
${e("messages")} { flex: 1; overflow-y: auto; padding: 8px; display: flex; flex-direction: column; gap: 6px; }
${e("msg")} {
  max-width: 85%;
  padding: 6px 8px;
  border: 1px solid var(--line);
  border-radius: var(--r-md);
  background: var(--bg-2);
  overflow-wrap: anywhere;
}
${e("msg--out")} { align-self: flex-end; background: var(--bg-3); }
${e("msg--failed")} { border-color: var(--amber); }
${e("msg-meta")} { margin-top: 2px; font-size: 11px; color: var(--fg-2); }
${e("composer")} {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 8px;
  border-top: 1px solid var(--line);
  background: var(--panel-bot);
}
${e("row")} { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
${e("grow")} { flex: 1; }
${e("field")} { display: flex; flex-direction: column; gap: 2px; }
${e("input")} {
  width: 100%;
  min-height: 32px;
  padding: 6px 8px;
  border: 1px solid var(--line-strong);
  border-radius: var(--r-sm);
  background: var(--bg-inset);
  color: var(--fg-0);
  font: inherit;
  resize: vertical;
}
${e("button")} {
  min-height: 32px;
  padding: 4px 12px;
  border: 1px solid var(--line-strong);
  border-radius: var(--r-sm);
  background: var(--bg-3);
  color: var(--fg-0);
  font: inherit;
  cursor: pointer;
}
${e("button--primary")} { border-color: var(--accent); }
${e("button")}:disabled { cursor: not-allowed; color: var(--fg-3); border-color: var(--line); }
${r} :focus-visible { outline: 2px solid var(--accent-bright); outline-offset: 2px; }
${e("notice")} {
  margin: 8px;
  padding: 8px;
  border: 1px solid var(--line);
  border-radius: var(--r-md);
  background: var(--bg-2);
}
${e("notice--warn")} { border-color: var(--amber); }
${e("over")} { color: var(--amber); font-weight: 600; }
${e("back")} { display: none; }
${e("tabs")} {
  display: flex;
  flex-wrap: wrap;
  align-items: stretch;
  gap: 2px;
  padding: 0 6px;
  border-bottom: 1px solid var(--line);
  background: var(--bg-0);
}
${e("tab")} {
  min-height: 36px;
  padding: 0 12px;
  border: 0;
  border-bottom: 2px solid var(--bg-0);
  background: none;
  color: var(--fg-2);
  font: inherit;
  font-weight: 600;
  cursor: pointer;
}
${e("tab--on")} { color: var(--fg-0); border-bottom-color: var(--accent); }
${e("pane")} { flex: 1; min-height: 0; overflow-y: auto; padding: 12px; display: flex; flex-direction: column; gap: 12px; }
${e("card")} { padding: 12px; border: 1px solid var(--panel-border); border-radius: var(--r-md); background: var(--bg-2); display: flex; flex-direction: column; gap: 8px; }
${e("card-head")} { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }
${e("h")} { margin: 0; font-size: 14px; font-weight: 600; color: var(--fg-0); }
${e("table")} { width: 100%; border-collapse: collapse; }
${e("table")} th { padding: 6px 8px; text-align: left; color: var(--fg-2); font-size: 11px; font-weight: 600; border-bottom: 1px solid var(--line); }
${e("table")} td { padding: 6px 8px; border-bottom: 1px solid var(--line); vertical-align: middle; }
${e("num")} { font-family: var(--font-mono); text-align: right; white-space: nowrap; }
${e("table")} th${e("num")} { text-align: right; }
${e("mono")} { font-family: var(--font-mono); }
${e("scroll-x")} { overflow-x: auto; }
${e("tx-label")} {
  display: inline-block;
  padding: 1px 6px;
  border: 1px solid var(--line-strong);
  border-radius: var(--r-xs);
  color: var(--fg-2);
  font-size: 11px;
  white-space: nowrap;
}
${e("tx-label--auto")} { border-color: var(--amber); color: var(--amber); }
${e("help")} { color: var(--fg-2); font-size: 12px; line-height: 1.5; }
${e("progress")} { height: 4px; border-radius: var(--r-xs); background: var(--bg-3); overflow: hidden; }
${e("progress-bar")} { height: 4px; background: var(--accent); }
${e("divider")} { display: flex; align-items: center; gap: 8px; color: var(--fg-2); font-size: 12px; }
${e("divider")}::before, ${e("divider")}::after { content: ""; flex: 1; height: 1px; background: var(--line); }
${e("ok")} { color: var(--ok); }
${e("warn")} { color: var(--amber); }
${e("tx-text")} { color: var(--tx); }
${e("thread-tools")} {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border-bottom: 1px solid var(--line);
  background: var(--bg-2);
  font-size: 12px;
}
${e("link")} {
  padding: 0;
  border: 0;
  background: none;
  color: var(--accent-bright);
  font: inherit;
  text-decoration: underline;
  cursor: pointer;
}
${e("link")}:disabled { color: var(--fg-3); cursor: not-allowed; text-decoration: none; }
${e("log")} {
  margin: 0;
  padding: 0;
  list-style: none;
  max-height: 22em;
  overflow-y: auto;
  border: 1px solid var(--line);
  border-radius: var(--r-sm);
  background: var(--bg-inset);
}
${e("log-line")} {
  display: grid;
  grid-template-columns: auto 1.6em 1fr;
  gap: 8px;
  padding: 3px 8px;
  border-bottom: 1px solid var(--line);
  font-size: 12px;
  line-height: 1.5;
  overflow-wrap: anywhere;
}
${e("log-line")}:last-child { border-bottom: 0; }
${e("chip")} {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 28px;
  padding: 0 10px;
  border: 1px solid var(--line-strong);
  border-radius: var(--r-lg);
  background: var(--bg-1);
  font-size: 12px;
}
@container (max-width: 520px) {
  ${e("body")} { grid-template-columns: 1fr; }
  ${e("body--thread")} ${e("list")} { display: none; }
  ${e("body--list")} ${e("thread")} { display: none; }
  ${e("list")} { border-right: 0; }
  ${e("back")} { display: inline-block; }
}
`;
var injected = false;
function injectStyles() {
	if (injected) return;
	injected = true;
	const style = document.createElement("style");
	style.setAttribute("data-feature", ROOT);
	style.textContent = css;
	document.head.appendChild(style);
}
//#endregion
//#region src/Inbox.tsx
function conversationTitle(c) {
	if (c.title) return c.title;
	if (c.kind === "channel") return `Channel ${c.peer}`;
	return c.peer.length > 12 ? `${c.peer.slice(0, 12)}…` : c.peer;
}
function kindLabel(kind) {
	return kind === "channel" ? "channel" : kind === "room" ? "room" : "direct";
}
function Inbox({ client, status }) {
	const [list] = usePoll(() => client.conversations(), 2e3, [client, status.version]);
	const [selectedId, setSelectedId] = useState(null);
	const [composingNew, setComposingNew] = useState(false);
	const [search, setSearch] = useState("");
	const everything = list.kind === "ready" ? list.data : [];
	const needle = search.trim().toLowerCase();
	const conversations = needle ? everything.filter((c) => conversationTitle(c).toLowerCase().includes(needle) || c.peer.toLowerCase().includes(needle) || (c.last?.text ?? "").toLowerCase().includes(needle) || (c.last?.fromName ?? "").toLowerCase().includes(needle)) : everything;
	const selected = conversations.find((c) => c.id === selectedId) ?? null;
	const nodeById = useMemo(() => new Map(status.nodes.map((n) => [n.id, n])), [status.nodes]);
	const bodyMode = selected || composingNew ? "thread" : "list";
	return /* @__PURE__ */ jsxs("div", {
		className: `${cx("body")} ${cx(`body--${bodyMode}`)}`,
		children: [/* @__PURE__ */ jsxs("div", {
			className: cx("list"),
			children: [
				/* @__PURE__ */ jsxs("div", {
					style: { padding: 8 },
					children: [/* @__PURE__ */ jsx("button", {
						type: "button",
						className: `${cx("button")} ${cx("button--primary")}`,
						onClick: () => {
							setSelectedId(null);
							setComposingNew(true);
						},
						children: "New message"
					}), everything.length > 3 && /* @__PURE__ */ jsx("input", {
						className: cx("input"),
						style: { marginTop: 8 },
						value: search,
						placeholder: "Search conversations",
						"aria-label": "Search conversations",
						onChange: (e) => setSearch(e.target.value)
					})]
				}),
				list.kind === "error" && /* @__PURE__ */ jsxs("p", {
					className: `${cx("notice")} ${cx("notice--warn")}`,
					role: "alert",
					children: ["Couldn’t load conversations: ", list.message]
				}),
				list.kind === "ready" && everything.length === 0 && /* @__PURE__ */ jsx("p", {
					className: cx("notice"),
					children: "No messages yet."
				}),
				list.kind === "ready" && everything.length > 0 && conversations.length === 0 && /* @__PURE__ */ jsxs("p", {
					className: cx("notice"),
					children: [
						"Nothing matches “",
						search,
						"”."
					]
				}),
				/* @__PURE__ */ jsx("ul", {
					"aria-label": "Conversations",
					style: {
						margin: 0,
						padding: 0,
						listStyle: "none"
					},
					children: conversations.map((c) => {
						const node = nodeById.get(c.connectorId);
						const isSelected = c.id === selectedId;
						return /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("button", {
							type: "button",
							className: `${cx("item")} ${isSelected ? cx("item--selected") : ""}`,
							"aria-current": isSelected ? "true" : void 0,
							onClick: () => {
								setComposingNew(false);
								setSelectedId(c.id);
							},
							children: [/* @__PURE__ */ jsxs("span", {
								className: cx("item-top"),
								children: [
									/* @__PURE__ */ jsx(NetworkBadge, { network: c.network }),
									/* @__PURE__ */ jsx("span", {
										className: cx("item-title"),
										children: conversationTitle(c)
									}),
									c.unread > 0 && !isSelected && /* @__PURE__ */ jsx("span", {
										className: cx("unread"),
										"aria-label": `${c.unread} unread`,
										children: c.unread
									})
								]
							}), /* @__PURE__ */ jsxs("span", {
								className: cx("item-preview"),
								children: [
									kindLabel(c.kind),
									" · ",
									node?.name ?? "removed node",
									c.last ? ` · ${c.last.text}` : ""
								]
							})]
						}) }, c.id);
					})
				})
			]
		}), composingNew ? /* @__PURE__ */ jsx(NewConversation, {
			client,
			nodes: status.nodes,
			onCancel: () => setComposingNew(false),
			onStarted: (id) => {
				setComposingNew(false);
				setSelectedId(id);
			}
		}) : selected ? /* @__PURE__ */ jsx(Thread, {
			client,
			conversation: selected,
			node: nodeById.get(selected.connectorId) ?? null,
			version: status.version,
			onBack: () => setSelectedId(null),
			onDeleted: () => setSelectedId(null)
		}, selected.id) : /* @__PURE__ */ jsx("div", {
			className: cx("thread"),
			children: /* @__PURE__ */ jsx("p", {
				className: cx("notice"),
				children: "Select a conversation, or start a new message."
			})
		})]
	});
}
function statusLine(m) {
	switch (m.status) {
		case "sending": return {
			text: "Sending…",
			warn: false
		};
		case "sent": return {
			text: m.flood ? "Sent (flood)" : "Sent",
			warn: false
		};
		case "delivered": return {
			text: m.roundTripMs ? `Delivered · ${(m.roundTripMs / 1e3).toFixed(1)} s` : "Delivered",
			warn: false
		};
		case "notconfirmed": return {
			text: "Sent · no acknowledgement",
			warn: true
		};
		case "failed": return {
			text: `Not sent — ${m.error ?? "unknown error"}`,
			warn: true
		};
		default: return {
			text: "",
			warn: false
		};
	}
}
function receptionLine(m) {
	const r = m.reception;
	if (!r) return "";
	const parts = [];
	if (r.snr !== void 0 && r.snr !== null) parts.push(`SNR ${r.snr.toFixed(2)} dB`);
	if (r.rssi !== void 0 && r.rssi !== null) parts.push(`RSSI ${r.rssi} dBm`);
	if (r.direct) parts.push("direct");
	else if (r.hops !== void 0 && r.hops !== null) parts.push(`${r.hops} hop${r.hops === 1 ? "" : "s"}`);
	if (r.viaMqtt) parts.push("via MQTT");
	return parts.join(" · ");
}
function Thread(props) {
	const { client, conversation, node } = props;
	const [messages, reload] = usePoll(() => client.messages(conversation.id), 2e3, [
		client,
		conversation.id,
		props.version
	]);
	const [draft, setDraft] = useState("");
	const [sending, setSending] = useState(false);
	const [sendError, setSendError] = useState(null);
	const [muted, setMuted] = useState(conversation.muted);
	const [confirmDelete, setConfirmDelete] = useState(false);
	const [busy, setBusy] = useState(false);
	const [notice, setNotice] = useState(null);
	const [retrying, setRetrying] = useState(null);
	const bytes = utf8Length(draft.trim());
	const max = node ? textLimit(node, conversation.kind) : 0;
	const connected = node?.state === "connected";
	const canSend = connected && !sending && bytes > 0 && bytes <= max;
	const via = node ? `${node.name} (${networkLabel[node.network]})` : "a node that's no longer configured";
	const send = async () => {
		if (!canSend) return;
		setSending(true);
		setSendError(null);
		try {
			const result = await client.reply(conversation.id, draft);
			if (result.ok) setDraft("");
			else setSendError(result.error ?? "Send failed.");
		} catch (err) {
			setSendError(errorText(err));
		} finally {
			setSending(false);
		}
	};
	const list = messages.kind === "ready" ? messages.data : [];
	const firstLive = list.findIndex((m) => !m.queuedWhileAway);
	const hasQueued = list.some((m) => m.queuedWhileAway);
	const failedCount = list.filter((m) => m.direction === "outbound" && (m.status === "failed" || m.status === "notconfirmed")).length;
	const retry = async (messageId) => {
		setRetrying(messageId);
		setNotice(null);
		try {
			const result = await client.retry(conversation.id, messageId);
			if (!result.ok) setNotice(result.error ?? "Still couldn’t send it.");
			reload();
		} catch (err) {
			setNotice(errorText(err));
		} finally {
			setRetrying(null);
		}
	};
	const clearFailed = async () => {
		setBusy(true);
		setNotice(null);
		try {
			const result = await client.clearFailed(conversation.id);
			setNotice(result.count > 0 ? `Removed ${result.count} message${result.count === 1 ? "" : "s"}.` : "Nothing to remove.");
			reload();
		} catch (err) {
			setNotice(errorText(err));
		} finally {
			setBusy(false);
		}
	};
	const remove = async () => {
		setBusy(true);
		try {
			await client.deleteConversation(conversation.id);
			props.onDeleted();
		} catch (err) {
			setNotice(errorText(err));
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("section", {
		className: cx("thread"),
		"aria-label": `Conversation ${conversationTitle(conversation)}`,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: cx("thread-head"),
				children: [
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: `${cx("button")} ${cx("back")}`,
						onClick: props.onBack,
						children: "Back"
					}),
					/* @__PURE__ */ jsx(NetworkBadge, { network: conversation.network }),
					/* @__PURE__ */ jsx("strong", { children: conversationTitle(conversation) }),
					/* @__PURE__ */ jsxs("span", {
						className: cx("muted"),
						children: [
							kindLabel(conversation.kind),
							" · on ",
							via
						]
					}),
					/* @__PURE__ */ jsx("span", { className: cx("grow") }),
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: cx("button"),
						"aria-pressed": muted,
						onClick: () => {
							const next = !muted;
							setMuted(next);
							client.mute(conversation.id, next);
						},
						children: muted ? "Unmute" : "Mute"
					}),
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: cx("button"),
						disabled: busy,
						onClick: () => setConfirmDelete(true),
						children: "Delete…"
					})
				]
			}),
			(failedCount > 0 || notice || confirmDelete) && /* @__PURE__ */ jsxs("div", {
				className: cx("thread-tools"),
				children: [
					failedCount > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
						/* @__PURE__ */ jsxs("span", {
							className: cx("muted"),
							children: [
								failedCount,
								" message",
								failedCount === 1 ? "" : "s",
								" never went out."
							]
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: cx("button"),
							disabled: busy,
							onClick: () => void clearFailed(),
							children: "Clear them"
						}),
						/* @__PURE__ */ jsx("span", {
							className: cx("tx-label"),
							children: "Transmits: no"
						})
					] }),
					notice && /* @__PURE__ */ jsx("span", {
						className: cx("muted"),
						children: notice
					}),
					confirmDelete && /* @__PURE__ */ jsxs(Fragment, { children: [
						/* @__PURE__ */ jsx("span", {
							className: cx("warn"),
							children: "Delete this conversation from Zeus? The messages are removed from Zeus only."
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: `${cx("button")} ${cx("button--primary")}`,
							disabled: busy,
							onClick: () => void remove(),
							children: "Delete"
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: cx("button"),
							onClick: () => setConfirmDelete(false),
							children: "Keep"
						})
					] })
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cx("messages"),
				"aria-live": "polite",
				children: [
					messages.kind === "loading" && /* @__PURE__ */ jsx("p", {
						className: cx("muted"),
						children: "Loading messages…"
					}),
					messages.kind === "error" && /* @__PURE__ */ jsxs("p", {
						className: `${cx("notice")} ${cx("notice--warn")}`,
						role: "alert",
						children: ["Couldn’t load messages: ", messages.message]
					}),
					messages.kind === "ready" && list.length === 0 && /* @__PURE__ */ jsx("p", {
						className: cx("muted"),
						children: "No messages yet."
					}),
					hasQueued && /* @__PURE__ */ jsx("div", {
						className: cx("divider"),
						children: "Received while Zeus was closed"
					}),
					list.map((m, i) => {
						const s = statusLine(m);
						const rx = receptionLine(m);
						return /* @__PURE__ */ jsxs("div", {
							style: { display: "contents" },
							children: [hasQueued && i === firstLive && i > 0 && /* @__PURE__ */ jsx("div", {
								className: cx("divider"),
								children: "Since Zeus connected"
							}), /* @__PURE__ */ jsxs("div", {
								className: `${cx("msg")} ${m.direction === "outbound" ? cx("msg--out") : ""} ${m.status === "failed" || m.status === "notconfirmed" ? cx("msg--failed") : ""}`,
								children: [
									m.direction === "inbound" && conversation.kind !== "direct" && /* @__PURE__ */ jsx("div", {
										style: {
											fontWeight: 600,
											fontSize: 12
										},
										children: m.fromName ?? m.fromId
									}),
									/* @__PURE__ */ jsx("div", { children: m.text }),
									/* @__PURE__ */ jsxs("div", {
										className: cx("msg-meta"),
										children: [
											new Date(m.timestamp).toLocaleString([], {
												dateStyle: "short",
												timeStyle: "short"
											}),
											rx && ` · ${rx}`,
											s.text && /* @__PURE__ */ jsxs("span", {
												className: s.warn ? cx("warn") : void 0,
												children: [" · ", s.text]
											}),
											m.direction === "outbound" && (m.status === "failed" || m.status === "notconfirmed") && /* @__PURE__ */ jsxs(Fragment, { children: [" · ", /* @__PURE__ */ jsx("button", {
												type: "button",
												className: cx("link"),
												disabled: !connected || retrying !== null,
												onClick: () => void retry(m.id),
												children: retrying === m.id ? "Sending…" : "Send again"
											})] })
										]
									})
								]
							})]
						}, m.id);
					})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cx("composer"),
				children: [
					!connected && /* @__PURE__ */ jsxs("p", {
						className: `${cx("notice")} ${cx("notice--warn")}`,
						role: "status",
						children: [
							node ? `${node.name} is ${node.state}.` : "This conversation’s node is no longer configured.",
							" Replies only go out on ",
							via,
							"; they are never re-sent on another network."
						]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: cx("field"),
						children: [/* @__PURE__ */ jsxs("span", {
							className: cx("muted"),
							children: [
								conversation.kind === "room" ? "Post to the room via" : "Reply via",
								" ",
								via
							]
						}), /* @__PURE__ */ jsx("textarea", {
							className: cx("input"),
							rows: 2,
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter" && !e.shiftKey) {
									e.preventDefault();
									send();
								}
							}
						})]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: cx("row"),
						children: [
							/* @__PURE__ */ jsxs("span", {
								className: bytes > max ? cx("over") : cx("muted"),
								children: [
									bytes,
									" / ",
									max,
									" bytes"
								]
							}),
							/* @__PURE__ */ jsx("span", { className: cx("grow") }),
							/* @__PURE__ */ jsx("button", {
								type: "button",
								className: `${cx("button")} ${cx("button--primary")}`,
								disabled: !canSend,
								onClick: () => void send(),
								children: sending ? "Sending…" : "Send"
							})
						]
					}),
					sendError && /* @__PURE__ */ jsx("p", {
						className: cx("over"),
						role: "alert",
						children: sendError
					})
				]
			})
		]
	});
}
function NewConversation(props) {
	const [nodeId, setNodeId] = useState(props.nodes.length === 1 ? props.nodes[0].id : "");
	const [kind, setKind] = useState("channel");
	const [peer, setPeer] = useState("");
	const [text, setText] = useState("");
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const [peers, setPeers] = useState([]);
	const node = props.nodes.find((n) => n.id === nodeId) ?? null;
	useEffect(() => {
		let alive = true;
		setPeers([]);
		if (!nodeId) return;
		props.client.peers(nodeId).then((p) => alive && setPeers(p.filter((x) => x.kind === "chat" || x.kind === "room"))).catch(() => alive && setPeers([]));
		return () => {
			alive = false;
		};
	}, [nodeId, props.client]);
	useEffect(() => {
		setPeer(kind === "channel" && node && node.channels.length > 0 ? String(node.channels[0].index) : "");
	}, [kind, nodeId]);
	const selectedPeer = peers.find((p) => p.id === peer);
	const effectiveKind = kind === "direct" && selectedPeer?.kind === "room" ? "room" : kind;
	const bytes = utf8Length(text.trim());
	const max = node ? textLimit(node, effectiveKind) : 0;
	const canSend = !!node && node.state === "connected" && !busy && peer !== "" && bytes > 0 && bytes <= max;
	const submit = async () => {
		if (!node || !canSend) return;
		setBusy(true);
		setError(null);
		try {
			const result = await props.client.start(node.id, effectiveKind, peer, text);
			if (result.conversationId && result.ok) props.onStarted(result.conversationId);
			else setError(result.error ?? "Send failed.");
		} catch (err) {
			setError(errorText(err));
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("section", {
		className: cx("thread"),
		"aria-label": "New message",
		children: [/* @__PURE__ */ jsxs("div", {
			className: cx("thread-head"),
			children: [/* @__PURE__ */ jsx("button", {
				type: "button",
				className: `${cx("button")} ${cx("back")}`,
				onClick: props.onCancel,
				children: "Back"
			}), /* @__PURE__ */ jsx("strong", { children: "New message" })]
		}), /* @__PURE__ */ jsxs("div", {
			className: cx("composer"),
			style: {
				flex: 1,
				overflowY: "auto"
			},
			children: [
				/* @__PURE__ */ jsxs("label", {
					className: cx("field"),
					children: [/* @__PURE__ */ jsx("span", { children: "Send from node (this sets the network)" }), /* @__PURE__ */ jsxs("select", {
						className: cx("input"),
						value: nodeId,
						onChange: (e) => setNodeId(e.target.value),
						children: [/* @__PURE__ */ jsx("option", {
							value: "",
							disabled: true,
							children: "Choose a node…"
						}), props.nodes.map((n) => /* @__PURE__ */ jsxs("option", {
							value: n.id,
							children: [
								networkLabel[n.network],
								" · ",
								n.name,
								" (",
								n.state,
								")"
							]
						}, n.id))]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: cx("row"),
					children: [/* @__PURE__ */ jsx("button", {
						type: "button",
						className: `${cx("button")} ${kind === "channel" ? cx("button--primary") : ""}`,
						"aria-pressed": kind === "channel",
						onClick: () => setKind("channel"),
						children: "Channel"
					}), /* @__PURE__ */ jsx("button", {
						type: "button",
						className: `${cx("button")} ${kind === "direct" ? cx("button--primary") : ""}`,
						"aria-pressed": kind === "direct",
						onClick: () => setKind("direct"),
						children: "Direct / room"
					})]
				}),
				kind === "channel" ? /* @__PURE__ */ jsxs("label", {
					className: cx("field"),
					children: [/* @__PURE__ */ jsx("span", { children: "Channel" }), /* @__PURE__ */ jsxs("select", {
						className: cx("input"),
						value: peer,
						onChange: (e) => setPeer(e.target.value),
						disabled: !node,
						children: [!node && /* @__PURE__ */ jsx("option", {
							value: "",
							children: "Choose a node first"
						}), node?.channels.map((c) => /* @__PURE__ */ jsxs("option", {
							value: String(c.index),
							children: [
								"#",
								c.index,
								" ",
								c.name,
								" (",
								c.kind,
								")"
							]
						}, c.index))]
					})]
				}) : /* @__PURE__ */ jsxs("label", {
					className: cx("field"),
					children: [/* @__PURE__ */ jsx("span", { children: "To" }), /* @__PURE__ */ jsxs("select", {
						className: cx("input"),
						value: peer,
						onChange: (e) => setPeer(e.target.value),
						disabled: !node,
						children: [/* @__PURE__ */ jsx("option", {
							value: "",
							children: node ? peers.length ? "Choose…" : "No contacts known yet" : "Choose a node first"
						}), peers.map((p) => /* @__PURE__ */ jsxs("option", {
							value: p.id,
							children: [
								p.kind === "room" ? "Room · " : "",
								p.name,
								p.shortName ? ` (${p.shortName})` : "",
								p.savedOnNode ? "" : " — heard, will be saved on send"
							]
						}, p.id))]
					})]
				}),
				/* @__PURE__ */ jsxs("label", {
					className: cx("field"),
					children: [/* @__PURE__ */ jsx("span", { children: "Message" }), /* @__PURE__ */ jsx("textarea", {
						className: cx("input"),
						rows: 3,
						value: text,
						onChange: (e) => setText(e.target.value)
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: cx("row"),
					children: [
						/* @__PURE__ */ jsx("span", {
							className: bytes > max ? cx("over") : cx("muted"),
							children: node ? `${bytes} / ${max} bytes` : "Choose a node first"
						}),
						/* @__PURE__ */ jsx("span", { className: cx("grow") }),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: cx("button"),
							onClick: props.onCancel,
							children: "Cancel"
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: `${cx("button")} ${cx("button--primary")}`,
							disabled: !canSend,
							onClick: () => void submit(),
							children: busy ? "Sending…" : node ? `Send via ${networkLabel[node.network]}` : "Send"
						})
					]
				}),
				node && /* @__PURE__ */ jsxs("p", {
					className: cx("help"),
					children: [
						"This conversation will belong to ",
						node.name,
						" (",
						networkLabel[node.network],
						"). Every reply in it goes out on that node only."
					]
				}),
				node && node.state !== "connected" && /* @__PURE__ */ jsxs("p", {
					className: `${cx("notice")} ${cx("notice--warn")}`,
					role: "status",
					children: [
						node.name,
						" is ",
						node.state,
						"."
					]
				}),
				error && /* @__PURE__ */ jsx("p", {
					className: cx("over"),
					role: "alert",
					children: error
				})
			]
		})]
	});
}
//#endregion
//#region src/Nodes.tsx
function matches(p, needle) {
	if (!needle) return true;
	return p.name.toLowerCase().includes(needle) || (p.shortName ?? "").toLowerCase().includes(needle) || p.id.toLowerCase().includes(needle) || p.kind.toLowerCase().includes(needle);
}
/** Heard nodes / contacts for each of our nodes. */
function Nodes({ client, nodes, onChanged }) {
	const [nodeId, setNodeId] = useState(nodes[0]?.id ?? "");
	const node = nodes.find((n) => n.id === nodeId) ?? nodes[0];
	const [peers, reloadPeers] = usePoll(() => node ? client.peers(node.id) : Promise.resolve([]), 5e3, [client, node?.id]);
	const [search, setSearch] = useState("");
	const [busy, setBusy] = useState(null);
	const [removing, setRemoving] = useState(null);
	const [note, setNote] = useState(null);
	const all = peers.kind === "ready" ? peers.data : [];
	const needle = search.trim().toLowerCase();
	const list = useMemo(() => all.filter((p) => matches(p, needle)), [all, needle]);
	const heardOnly = all.filter((p) => !p.savedOnNode).length;
	if (!node) return null;
	const capacity = node?.peerCapacity;
	const saved = all.filter((p) => p.savedOnNode).length;
	const full = capacity !== void 0 && saved >= capacity;
	const nearlyFull = capacity !== void 0 && !full && saved >= capacity * .9;
	const remove = async (peerId, name) => {
		setRemoving(peerId);
		setNote(null);
		try {
			const result = await client.removePeer(node.id, peerId);
			setNote(result.ok ? {
				kind: "ok",
				text: `Removed ${name} from the node.`
			} : {
				kind: "warn",
				text: result.error ?? "Couldn’t remove it."
			});
			reloadPeers();
			onChanged();
		} catch (err) {
			setNote({
				kind: "warn",
				text: errorText(err)
			});
		} finally {
			setRemoving(null);
		}
	};
	const run = async (what, action) => {
		setBusy(what);
		setNote(null);
		try {
			const result = await action();
			if (result.ok === false) setNote({
				kind: "warn",
				text: result.error ?? "That didn’t work."
			});
			else if (what === "refresh") setNote({
				kind: "ok",
				text: "Contacts re-read from the node."
			});
			else if (what === "recycle") setNote({
				kind: "ok",
				text: "Saved on the node."
			});
			else setNote({
				kind: "ok",
				text: "Advert sent. Other stations will list this node shortly."
			});
			reloadPeers();
			onChanged();
		} catch (err) {
			setNote({
				kind: "warn",
				text: errorText(err)
			});
		} finally {
			setBusy(null);
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		className: cx("pane"),
		children: [nodes.length > 1 && /* @__PURE__ */ jsx("div", {
			className: cx("row"),
			children: nodes.map((n) => /* @__PURE__ */ jsxs("button", {
				type: "button",
				className: `${cx("button")} ${n.id === node.id ? cx("button--primary") : ""}`,
				"aria-pressed": n.id === node.id,
				onClick: () => setNodeId(n.id),
				children: [
					/* @__PURE__ */ jsx(NetworkBadge, { network: n.network }),
					" ",
					n.name
				]
			}, n.id))
		}), /* @__PURE__ */ jsxs("div", {
			className: cx("card"),
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: cx("card-head"),
					children: [
						/* @__PURE__ */ jsx(NetworkBadge, { network: node.network }),
						/* @__PURE__ */ jsx("h2", {
							className: cx("h"),
							children: node.self?.name ?? node.name
						}),
						/* @__PURE__ */ jsx("span", {
							className: cx("muted"),
							children: [
								node.self?.model,
								node.self?.firmware,
								node.self?.radio
							].filter(Boolean).join(" · ") || node.detail
						})
					]
				}),
				/* @__PURE__ */ jsxs("p", {
					className: cx("help"),
					children: [
						node.network === "meshcore" ? "Stations this node knows. It learns them from adverts: another station announces itself and appears here." : "Nodes this node has heard. Meshtastic nodes announce themselves regularly, so this list fills in on its own.",
						" ",
						"SNR and hops are from the last packet heard."
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: cx("row"),
					children: [
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: cx("button"),
							disabled: busy !== null || node.state !== "connected",
							onClick: () => void run("refresh", () => client.refreshPeers(node.id).then(() => ({ ok: true }))),
							children: busy === "refresh" ? "Re-reading…" : "Re-read from node"
						}),
						/* @__PURE__ */ jsx("span", {
							className: cx("tx-label"),
							children: "Transmits: no"
						}),
						node.network === "meshcore" && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("button", {
							type: "button",
							className: cx("button"),
							disabled: busy !== null || node.state !== "connected",
							onClick: () => void run("advert", () => client.announce(node.id, true)),
							children: busy === "advert" ? "Sending…" : "Send advert"
						}), /* @__PURE__ */ jsx("span", {
							className: `${cx("tx-label")} ${cx("tx-label--auto")}`,
							children: "Transmits: yes"
						})] })
					]
				}),
				/* @__PURE__ */ jsxs("p", {
					className: cx("help"),
					children: [
						/* @__PURE__ */ jsx("strong", { children: "Re-read from node" }),
						" asks the node for its contact list again, which helps after adding a contact from the phone app. ",
						/* @__PURE__ */ jsx("strong", { children: "Send advert" }),
						" announces this node on the air so other stations can add it and message you; it is the only button here that transmits."
					]
				}),
				note && /* @__PURE__ */ jsx("p", {
					className: `${cx("notice")} ${note.kind === "warn" ? cx("notice--warn") : ""}`,
					role: "status",
					children: note.text
				}),
				heardOnly > 0 && /* @__PURE__ */ jsxs("p", {
					className: cx("help"),
					children: [
						heardOnly,
						" station",
						heardOnly === 1 ? " was" : "s were",
						" heard but not saved as contacts, because the node is set to add contacts manually. Zeus saves one automatically the first time you message it."
					]
				}),
				capacity !== void 0 && (full || nearlyFull) && /* @__PURE__ */ jsxs("div", {
					className: `${cx("notice")} ${cx("notice--warn")}`,
					role: "status",
					children: [
						/* @__PURE__ */ jsxs("strong", { children: [
							"The node’s contact list is ",
							full ? "full" : "nearly full",
							" (",
							saved,
							" of ",
							capacity,
							")."
						] }),
						" ",
						full ? "It cannot save any more stations, so a direct message to a station it hasn’t already saved will fail. Remove contacts you don’t need below, or let the node recycle the oldest one automatically." : "Once it is full the node can’t save new stations, and direct messages to them fail.",
						" ",
						"On a busy mesh the node adds every station it hears, so the list fills on its own."
					]
				}),
				node.recycleOldestWhenFull !== void 0 && node.recycleOldestWhenFull !== null && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("label", {
					className: cx("row"),
					children: [
						/* @__PURE__ */ jsx("input", {
							type: "checkbox",
							checked: node.recycleOldestWhenFull,
							disabled: busy !== null || node.state !== "connected",
							onChange: (e) => void run("recycle", () => client.setRecycleOldest(node.id, e.target.checked))
						}),
						/* @__PURE__ */ jsx("span", { children: "Recycle the oldest contact when the list is full" }),
						/* @__PURE__ */ jsx("span", {
							className: cx("tx-label"),
							children: "Transmits: no"
						})
					]
				}), /* @__PURE__ */ jsx("p", {
					className: cx("help"),
					children: "A setting on the node itself. With it on, the node drops its oldest non-favourite contact to make room for a new one, so the list never blocks new stations. With it off, a full list stays full until you remove something."
				})] }),
				/* @__PURE__ */ jsxs("label", {
					className: cx("field"),
					children: [/* @__PURE__ */ jsx("span", { children: "Search this list" }), /* @__PURE__ */ jsx("input", {
						className: cx("input"),
						value: search,
						placeholder: "Name, short name or key",
						onChange: (e) => setSearch(e.target.value)
					})]
				}),
				peers.kind === "loading" && /* @__PURE__ */ jsx("p", {
					className: cx("muted"),
					children: "Loading…"
				}),
				peers.kind === "error" && /* @__PURE__ */ jsx("p", {
					className: `${cx("notice")} ${cx("notice--warn")}`,
					role: "alert",
					children: peers.message
				}),
				peers.kind === "ready" && all.length === 0 && /* @__PURE__ */ jsxs("p", {
					className: cx("muted"),
					children: [
						"None yet. Ask another station to send an advert, or press ",
						/* @__PURE__ */ jsx("strong", { children: "Send advert" }),
						" so they can add this node and reply."
					]
				}),
				peers.kind === "ready" && all.length > 0 && list.length === 0 && /* @__PURE__ */ jsxs("p", {
					className: cx("muted"),
					children: [
						"Nothing matches “",
						search,
						"”."
					]
				}),
				list.length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("p", {
					className: cx("help"),
					children: [
						"Showing ",
						list.length,
						" of ",
						all.length,
						capacity !== void 0 ? ` · ${saved} of ${capacity} contact slots used on the node` : "",
						"."
					]
				}), /* @__PURE__ */ jsx("div", {
					className: cx("scroll-x"),
					children: /* @__PURE__ */ jsxs("table", {
						className: cx("table"),
						children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("th", { children: "Name" }),
							/* @__PURE__ */ jsx("th", { children: "Type" }),
							/* @__PURE__ */ jsx("th", { children: "Heard" }),
							/* @__PURE__ */ jsx("th", {
								className: cx("num"),
								children: "SNR"
							}),
							/* @__PURE__ */ jsx("th", {
								className: cx("num"),
								children: "Hops"
							}),
							/* @__PURE__ */ jsx("th", {
								className: cx("num"),
								children: "Batt"
							}),
							/* @__PURE__ */ jsx("th", {})
						] }) }), /* @__PURE__ */ jsx("tbody", { children: list.map((p) => /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsxs("td", { children: [
								p.favorite ? "★ " : "",
								/* @__PURE__ */ jsx("strong", { children: p.name }),
								p.shortName ? /* @__PURE__ */ jsxs("span", {
									className: cx("muted"),
									children: [
										" (",
										p.shortName,
										")"
									]
								}) : null,
								!p.savedOnNode ? /* @__PURE__ */ jsx("span", {
									className: cx("chip"),
									title: "Heard, but not saved as a contact on the node. Zeus saves it when you first message it.",
									children: "heard · not saved"
								}) : null,
								/* @__PURE__ */ jsx("div", {
									className: `${cx("muted")} ${cx("mono")}`,
									style: { fontSize: 11 },
									children: p.id.length > 16 ? `${p.id.slice(0, 12)}…` : p.id
								})
							] }),
							/* @__PURE__ */ jsx("td", { children: p.kind }),
							/* @__PURE__ */ jsx("td", {
								className: cx("mono"),
								children: ago(p.lastHeard)
							}),
							/* @__PURE__ */ jsx("td", {
								className: `${cx("num")} ${p.snr !== void 0 && p.snr !== null && p.snr < -10 ? cx("warn") : ""}`,
								children: p.snr ?? "—"
							}),
							/* @__PURE__ */ jsx("td", {
								className: cx("num"),
								children: p.hops ?? "—"
							}),
							/* @__PURE__ */ jsx("td", {
								className: cx("num"),
								children: p.batteryPercent !== void 0 && p.batteryPercent !== null ? `${p.batteryPercent}%` : "—"
							}),
							/* @__PURE__ */ jsx("td", { children: p.savedOnNode && node.network === "meshcore" && /* @__PURE__ */ jsx("button", {
								type: "button",
								className: cx("button"),
								disabled: removing !== null || node.state !== "connected",
								title: `Remove ${p.name} from the node's contact list`,
								onClick: () => void remove(p.id, p.name),
								children: removing === p.id ? "Removing…" : "Remove"
							}) })
						] }, p.id)) })]
					})
				})] })
			]
		})]
	});
}
//#endregion
//#region src/Settings.tsx
function TxNo() {
	return /* @__PURE__ */ jsx("span", {
		className: cx("tx-label"),
		children: "Transmits: no"
	});
}
function Settings({ client, status, onChanged }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cx("pane"),
		children: [
			/* @__PURE__ */ jsx(AddNode, {
				client,
				status,
				onChanged
			}),
			status.nodes.map((n) => /* @__PURE__ */ jsx(NodeEditor, {
				client,
				node: n,
				onChanged
			}, n.id)),
			/* @__PURE__ */ jsx(ScanRanges, {
				client,
				status,
				onChanged
			}),
			/* @__PURE__ */ jsx(History, {
				client,
				status,
				onChanged
			})
		]
	});
}
function AddNode({ client, status, onChanged }) {
	const [poll, setPoll] = useState(2e3);
	const [discovery, refresh] = usePoll(() => client.discovery(), poll, [client]);
	const [error, setError] = useState(null);
	const [adding, setAdding] = useState(null);
	const [manual, setManual] = useState(false);
	const scan = discovery.kind === "ready" ? discovery.data.scan : null;
	const running = !!scan?.running;
	useEffect(() => setPoll(running ? 700 : 4e3), [running]);
	const start = async () => {
		setError(null);
		try {
			await client.startScan([], true);
			refresh();
		} catch (err) {
			setError(errorText(err));
		}
	};
	const add = async (f) => {
		setAdding(f.identity);
		setError(null);
		try {
			await client.addNode({
				network: f.network,
				host: f.host,
				port: f.port,
				identity: f.identity
			});
			onChanged();
			refresh();
		} catch (err) {
			setError(errorText(err));
		} finally {
			setAdding(null);
		}
	};
	const networks = discovery.kind === "ready" ? discovery.data.defaultNetworks : [];
	const pct = scan && scan.total > 0 ? Math.round(100 * scan.probed / scan.total) : 0;
	return /* @__PURE__ */ jsxs("section", {
		className: cx("card"),
		"aria-label": "Add node",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: cx("card-head"),
				children: [
					/* @__PURE__ */ jsx("h2", {
						className: cx("h"),
						children: "Add node"
					}),
					/* @__PURE__ */ jsx("span", { className: cx("grow") }),
					/* @__PURE__ */ jsx(TxNo, {}),
					running ? /* @__PURE__ */ jsx("button", {
						type: "button",
						className: cx("button"),
						onClick: () => void client.stopScan().then(refresh),
						children: "Stop"
					}) : /* @__PURE__ */ jsx("button", {
						type: "button",
						className: `${cx("button")} ${cx("button--primary")}`,
						onClick: () => void start(),
						children: "Scan"
					})
				]
			}),
			/* @__PURE__ */ jsxs("p", {
				className: cx("help"),
				children: [
					"Scan looks for Meshtastic and MeshCore nodes on ",
					networks.length ? networks.join(", ") : "your network",
					status.scanRanges.length ? " (including your extra networks)" : "",
					" and checks each one really is a mesh node. It stays on your network — nothing is sent on the mesh. It can briefly disconnect a phone or meshcore-cli using a",
					" ",
					/* @__PURE__ */ jsx("em", { children: "different" }),
					" MeshCore node over Wi-Fi."
				]
			}),
			running && scan && /* @__PURE__ */ jsxs("div", {
				role: "status",
				children: [/* @__PURE__ */ jsx("div", {
					className: cx("progress"),
					"aria-hidden": "true",
					children: /* @__PURE__ */ jsx("div", {
						className: cx("progress-bar"),
						style: { width: `${pct}%` }
					})
				}), /* @__PURE__ */ jsx("span", {
					className: cx("muted"),
					children: scan.phase === "mdns" ? "Listening for Meshtastic announcements…" : `Checked ${scan.probed} of ${scan.total}`
				})]
			}),
			scan && !running && scan.phase !== "idle" && /* @__PURE__ */ jsx("span", {
				className: cx("muted"),
				children: scan.cancelled ? "Scan stopped." : scan.error ? `Scan failed: ${scan.error}` : `Scan finished: ${scan.found.length} node(s) found.`
			}),
			scan?.quietNetworks.length ? /* @__PURE__ */ jsxs("p", {
				className: `${cx("notice")} ${cx("notice--warn")}`,
				role: "status",
				children: [
					"Nothing answered on ",
					scan.quietNetworks.join(", "),
					". If nodes live there, your router or firewall must let this computer reach TCP 4403 (Meshtastic) and 5000 (MeshCore) on that network."
				]
			}) : null,
			scan && scan.found.length > 0 && /* @__PURE__ */ jsx("div", {
				className: cx("scroll-x"),
				children: /* @__PURE__ */ jsxs("table", {
					className: cx("table"),
					children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
						/* @__PURE__ */ jsx("th", { children: "Node" }),
						/* @__PURE__ */ jsx("th", { children: "Address" }),
						/* @__PURE__ */ jsx("th", { children: "Identity" }),
						/* @__PURE__ */ jsx("th", {})
					] }) }), /* @__PURE__ */ jsx("tbody", { children: scan.found.map((f) => /* @__PURE__ */ jsxs("tr", { children: [
						/* @__PURE__ */ jsxs("td", { children: [
							/* @__PURE__ */ jsx(NetworkBadge, { network: f.network }),
							" ",
							/* @__PURE__ */ jsx("strong", { children: f.name }),
							f.shortName ? /* @__PURE__ */ jsxs("span", {
								className: cx("muted"),
								children: [
									" (",
									f.shortName,
									")"
								]
							}) : null,
							/* @__PURE__ */ jsx("div", {
								className: cx("muted"),
								style: { fontSize: 11 },
								children: [
									f.model,
									f.firmware,
									f.foundBy.includes("mdns") ? "announced on this network" : "found by scan"
								].filter(Boolean).join(" · ")
							})
						] }),
						/* @__PURE__ */ jsx("td", {
							className: cx("mono"),
							children: f.host
						}),
						/* @__PURE__ */ jsx("td", {
							className: cx("mono"),
							children: f.identity.length > 14 ? `${f.identity.slice(0, 10)}…` : f.identity
						}),
						/* @__PURE__ */ jsx("td", { children: f.addedAs ? /* @__PURE__ */ jsx("span", {
							className: cx("ok"),
							children: "✓ Added"
						}) : /* @__PURE__ */ jsx("button", {
							type: "button",
							className: `${cx("button")} ${cx("button--primary")}`,
							disabled: adding !== null,
							onClick: () => void add(f),
							children: adding === f.identity ? "Adding…" : "Add"
						}) })
					] }, `${f.network}-${f.identity}`)) })]
				})
			}),
			error && /* @__PURE__ */ jsx("p", {
				className: cx("over"),
				role: "alert",
				children: error
			}),
			/* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("button", {
				type: "button",
				className: cx("button"),
				"aria-expanded": manual,
				onClick: () => setManual(!manual),
				children: manual ? "Hide manual entry" : "Add manually"
			}) }),
			manual && /* @__PURE__ */ jsx(ManualAdd, {
				client,
				onAdded: onChanged
			})
		]
	});
}
function ManualAdd({ client, onAdded }) {
	const [network, setNetwork] = useState("");
	const [host, setHost] = useState("");
	const [name, setName] = useState("");
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const submit = async () => {
		if (!network) return;
		setBusy(true);
		setError(null);
		try {
			await client.addNode({
				network,
				host,
				name
			});
			setHost("");
			setName("");
			onAdded();
		} catch (err) {
			setError(errorText(err));
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		className: cx("row"),
		style: { alignItems: "flex-end" },
		children: [
			/* @__PURE__ */ jsxs("label", {
				className: cx("field"),
				children: [/* @__PURE__ */ jsx("span", { children: "Network" }), /* @__PURE__ */ jsxs("select", {
					className: cx("input"),
					value: network,
					onChange: (e) => setNetwork(e.target.value),
					children: [
						/* @__PURE__ */ jsx("option", {
							value: "",
							disabled: true,
							children: "Choose…"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "meshtastic",
							children: "Meshtastic (port 4403)"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "meshcore",
							children: "MeshCore (port 5000)"
						})
					]
				})]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: `${cx("field")} ${cx("grow")}`,
				children: [/* @__PURE__ */ jsx("span", { children: "Address or host name (host:port for a non-standard port)" }), /* @__PURE__ */ jsx("input", {
					className: cx("input"),
					value: host,
					onChange: (e) => setHost(e.target.value),
					placeholder: "192.168.1.47"
				})]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: cx("field"),
				children: [/* @__PURE__ */ jsx("span", { children: "Name in Zeus (optional)" }), /* @__PURE__ */ jsx("input", {
					className: cx("input"),
					value: name,
					onChange: (e) => setName(e.target.value)
				})]
			}),
			/* @__PURE__ */ jsx("button", {
				type: "button",
				className: `${cx("button")} ${cx("button--primary")}`,
				disabled: !network || !host.trim() || busy,
				onClick: () => void submit(),
				children: busy ? "Adding…" : "Add"
			}),
			error && /* @__PURE__ */ jsx("p", {
				className: cx("over"),
				role: "alert",
				style: { flexBasis: "100%" },
				children: error
			})
		]
	});
}
function NodeEditor({ client, node, onChanged }) {
	const [name, setName] = useState(node.name);
	const [host, setHost] = useState(node.host);
	const [port, setPort] = useState(String(node.port));
	const [error, setError] = useState(null);
	const [confirmRemove, setConfirmRemove] = useState(false);
	useEffect(() => setHost(node.host), [node.host]);
	const run = async (action) => {
		setError(null);
		try {
			await action();
			onChanged();
		} catch (err) {
			setError(errorText(err));
		}
	};
	const dirty = name !== node.name || host !== node.host || port !== String(node.port);
	return /* @__PURE__ */ jsxs("section", {
		className: cx("card"),
		"aria-label": `Node ${node.name}`,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: cx("card-head"),
				children: [
					/* @__PURE__ */ jsx(NetworkBadge, { network: node.network }),
					/* @__PURE__ */ jsx("h2", {
						className: cx("h"),
						children: node.name
					}),
					/* @__PURE__ */ jsx("span", {
						className: node.state === "connected" ? cx("ok") : node.state === "error" ? cx("warn") : cx("muted"),
						children: node.state
					}),
					/* @__PURE__ */ jsx("span", {
						className: cx("muted"),
						children: node.detail
					})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cx("row"),
				style: { alignItems: "flex-end" },
				children: [
					/* @__PURE__ */ jsxs("label", {
						className: `${cx("field")} ${cx("grow")}`,
						children: [/* @__PURE__ */ jsx("span", { children: "Name shown in Zeus" }), /* @__PURE__ */ jsx("input", {
							className: cx("input"),
							value: name,
							onChange: (e) => setName(e.target.value)
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: `${cx("field")} ${cx("grow")}`,
						children: [/* @__PURE__ */ jsx("span", { children: "Address (found by scan; you can type one)" }), /* @__PURE__ */ jsx("input", {
							className: `${cx("input")} ${cx("mono")}`,
							value: host,
							onChange: (e) => setHost(e.target.value)
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: cx("field"),
						style: { width: 90 },
						children: [/* @__PURE__ */ jsx("span", { children: "Port" }), /* @__PURE__ */ jsx("input", {
							className: `${cx("input")} ${cx("mono")}`,
							inputMode: "numeric",
							value: port,
							onChange: (e) => setPort(e.target.value)
						})]
					}),
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: `${cx("button")} ${cx("button--primary")}`,
						disabled: !dirty,
						onClick: () => void run(() => client.updateNode(node.id, {
							name,
							host,
							port: Number(port) || 0
						})),
						children: "Save"
					})
				]
			}),
			/* @__PURE__ */ jsxs("p", {
				className: cx("help"),
				children: [
					networkLabel[node.network],
					" · paired with",
					" ",
					/* @__PURE__ */ jsx("span", {
						className: cx("mono"),
						children: node.identity ? node.identity.length > 14 ? `${node.identity.slice(0, 10)}…` : node.identity : "the first node found at this address"
					}),
					". Zeus refuses a different node at this address, so replies can never go out from the wrong station."
				]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: cx("row"),
				children: [
					/* @__PURE__ */ jsx("input", {
						type: "checkbox",
						checked: node.enabled,
						onChange: (e) => void run(() => client.updateNode(node.id, { enabled: e.target.checked }))
					}),
					/* @__PURE__ */ jsx("span", { children: "Enabled" }),
					/* @__PURE__ */ jsx(TxNo, {})
				]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: cx("row"),
				children: [
					/* @__PURE__ */ jsx("input", {
						type: "checkbox",
						checked: node.findIfAddressChanges,
						onChange: (e) => void run(() => client.updateNode(node.id, { findIfAddressChanges: e.target.checked }))
					}),
					/* @__PURE__ */ jsx("span", { children: "Find this node automatically if its address changes" }),
					/* @__PURE__ */ jsx("span", {
						className: cx("tx-label"),
						children: "Transmits: no (network only)"
					})
				]
			}),
			/* @__PURE__ */ jsx("p", {
				className: cx("help"),
				children: "If it stops answering, Zeus checks its host name, then its network announcement (Meshtastic), then scans the network it was last on and your extra networks, and reconnects when it finds the same node."
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cx("row"),
				children: [
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: cx("button"),
						onClick: () => void run(() => client.repairNode(node.id)),
						children: "Re-pair"
					}),
					/* @__PURE__ */ jsx("span", {
						className: cx("help"),
						children: "After re-flashing or replacing the board."
					}),
					/* @__PURE__ */ jsx("span", { className: cx("grow") }),
					confirmRemove ? /* @__PURE__ */ jsxs(Fragment, { children: [
						/* @__PURE__ */ jsxs("span", {
							className: cx("warn"),
							children: [
								"Remove ",
								node.name,
								"? Its conversations stay in history."
							]
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: cx("button"),
							onClick: () => void run(() => client.removeNode(node.id)),
							children: "Remove"
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: cx("button"),
							onClick: () => setConfirmRemove(false),
							children: "Keep"
						})
					] }) : /* @__PURE__ */ jsx("button", {
						type: "button",
						className: cx("button"),
						onClick: () => setConfirmRemove(true),
						children: "Remove node…"
					})
				]
			}),
			error && /* @__PURE__ */ jsx("p", {
				className: cx("over"),
				role: "alert",
				children: error
			})
		]
	});
}
function ScanRanges({ client, status, onChanged }) {
	const [draft, setDraft] = useState("");
	const [error, setError] = useState(null);
	const save = async (ranges) => {
		setError(null);
		try {
			await client.saveSettings({ scanRanges: ranges });
			setDraft("");
			onChanged();
		} catch (err) {
			setError(errorText(err));
		}
	};
	return /* @__PURE__ */ jsxs("section", {
		className: cx("card"),
		"aria-label": "Extra networks to scan",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: cx("card-head"),
				children: [
					/* @__PURE__ */ jsx("h2", {
						className: cx("h"),
						children: "Extra networks to scan"
					}),
					/* @__PURE__ */ jsx("span", { className: cx("grow") }),
					/* @__PURE__ */ jsx(TxNo, {})
				]
			}),
			/* @__PURE__ */ jsx("p", {
				className: cx("help"),
				children: "Other VLANs to search, e.g. an IoT network. Used by Scan and when looking for a node that moved. Local addresses only, up to 4,094 addresses each (a /20)."
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cx("row"),
				children: [status.scanRanges.length === 0 && /* @__PURE__ */ jsx("span", {
					className: cx("muted"),
					children: "None."
				}), status.scanRanges.map((r) => /* @__PURE__ */ jsxs("span", {
					className: cx("chip"),
					children: [/* @__PURE__ */ jsx("span", {
						className: cx("mono"),
						children: r
					}), /* @__PURE__ */ jsx("button", {
						type: "button",
						className: cx("button"),
						"aria-label": `Remove ${r}`,
						onClick: () => void save(status.scanRanges.filter((x) => x !== r)),
						children: "Remove"
					})]
				}, r))]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cx("row"),
				children: [/* @__PURE__ */ jsxs("label", {
					className: `${cx("field")} ${cx("grow")}`,
					children: [/* @__PURE__ */ jsx("span", { children: "Add a network" }), /* @__PURE__ */ jsx("input", {
						className: `${cx("input")} ${cx("mono")}`,
						placeholder: "192.168.30.0/24",
						value: draft,
						onChange: (e) => setDraft(e.target.value)
					})]
				}), /* @__PURE__ */ jsx("button", {
					type: "button",
					className: cx("button"),
					style: { alignSelf: "flex-end" },
					disabled: !draft.trim(),
					onClick: () => void save([...status.scanRanges, draft.trim()]),
					children: "Add"
				})]
			}),
			error && /* @__PURE__ */ jsx("p", {
				className: cx("over"),
				role: "alert",
				children: error
			})
		]
	});
}
function History({ client, status, onChanged }) {
	const [value, setValue] = useState(String(status.historyPerConversation));
	return /* @__PURE__ */ jsxs("section", {
		className: cx("card"),
		"aria-label": "History",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: cx("card-head"),
				children: [
					/* @__PURE__ */ jsx("h2", {
						className: cx("h"),
						children: "History"
					}),
					/* @__PURE__ */ jsx("span", { className: cx("grow") }),
					/* @__PURE__ */ jsx(TxNo, {})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cx("row"),
				children: [/* @__PURE__ */ jsxs("label", {
					className: cx("field"),
					children: [/* @__PURE__ */ jsx("span", { children: "Messages kept per conversation (20–5000)" }), /* @__PURE__ */ jsx("input", {
						className: `${cx("input")} ${cx("mono")}`,
						inputMode: "numeric",
						value,
						onChange: (e) => setValue(e.target.value)
					})]
				}), /* @__PURE__ */ jsx("button", {
					type: "button",
					className: cx("button"),
					style: { alignSelf: "flex-end" },
					disabled: value === String(status.historyPerConversation),
					onClick: () => void client.saveSettings({ historyPerConversation: Number(value) || 500 }).then(onChanged),
					children: "Save"
				})]
			}),
			/* @__PURE__ */ jsx("p", {
				className: cx("help"),
				children: "Kept across Zeus restarts. Older messages are removed from Zeus only."
			})
		]
	});
}
//#endregion
//#region src/Debug.tsx
var levelClass = {
	info: "muted",
	send: "tx-text",
	receive: "ok",
	warning: "warn",
	error: "warn"
};
var levelLabel = {
	info: "·",
	send: "TX",
	receive: "RX",
	warning: "!",
	error: "✕"
};
function time(iso) {
	const d = new Date(iso);
	return Number.isNaN(d.getTime()) ? iso : d.toLocaleTimeString();
}
/** Plain text of everything on screen, for pasting into a bug report. */
function asText(nodes, version) {
	const lines = [`Mesh Messenger ${version} — ${(/* @__PURE__ */ new Date()).toISOString()}`];
	for (const n of nodes) {
		lines.push("", `Node ${n.name} (${n.network}) ${n.host}:${n.port} — ${n.state}${n.detail ? `: ${n.detail}` : ""}`, `  firmware ${n.self?.firmware ?? "?"} · model ${n.self?.model ?? "?"} · radio ${n.self?.radio ?? "?"}`, `  contacts ${n.contacts}${n.contactCapacity ? `/${n.contactCapacity}` : ""} saved, ${n.contactsHeardOnly} heard only · recycle-oldest ${n.recycleOldestWhenFull ?? "n/a"} · channels ${n.channels}`);
		for (const a of n.activity) lines.push(`  ${a.at} [${a.level}] ${a.text}`);
	}
	return lines.join("\n");
}
function Debug({ client }) {
	const [state] = usePoll(() => client.debug(), 2e3, [client]);
	const [filter, setFilter] = useState("");
	const [copied, setCopied] = useState(false);
	const nodes = state.kind === "ready" ? state.data.nodes : [];
	const needle = filter.trim().toLowerCase();
	const shown = useMemo(() => nodes.map((n) => ({
		node: n,
		activity: needle ? n.activity.filter((a) => a.text.toLowerCase().includes(needle)) : n.activity
	})), [nodes, needle]);
	const copy = async () => {
		if (state.kind !== "ready") return;
		try {
			await navigator.clipboard.writeText(asText(nodes, state.data.pluginVersion));
			setCopied(true);
			setTimeout(() => setCopied(false), 2e3);
		} catch {
			setCopied(false);
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		className: cx("pane"),
		children: [
			/* @__PURE__ */ jsxs("section", {
				className: cx("card"),
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: cx("row"),
						children: [
							/* @__PURE__ */ jsx("h2", {
								className: cx("h"),
								children: "Activity log"
							}),
							/* @__PURE__ */ jsx("span", { className: cx("grow") }),
							/* @__PURE__ */ jsx("span", {
								className: cx("tx-label"),
								children: "Transmits: no"
							}),
							/* @__PURE__ */ jsx("button", {
								type: "button",
								className: cx("button"),
								onClick: () => void copy(),
								children: copied ? "Copied" : "Copy all"
							})
						]
					}),
					/* @__PURE__ */ jsx("p", {
						className: cx("help"),
						children: "What each node and Zeus have done recently — connects, commands, replies and errors. Message text is never logged. The log is kept in memory only and starts empty each time Zeus opens. Copy it into a bug report when something doesn’t work."
					}),
					/* @__PURE__ */ jsxs("label", {
						className: cx("field"),
						children: [/* @__PURE__ */ jsx("span", { children: "Search the log" }), /* @__PURE__ */ jsx("input", {
							className: cx("input"),
							value: filter,
							placeholder: "e.g. advert, ack, failed",
							onChange: (e) => setFilter(e.target.value)
						})]
					})
				]
			}),
			state.kind === "error" && /* @__PURE__ */ jsxs("p", {
				className: `${cx("notice")} ${cx("notice--warn")}`,
				role: "alert",
				children: [
					"Can’t read the log (",
					state.message,
					")."
				]
			}),
			state.kind === "ready" && nodes.length === 0 && /* @__PURE__ */ jsx("p", {
				className: cx("help"),
				children: "No nodes yet."
			}),
			shown.map(({ node, activity }) => /* @__PURE__ */ jsxs("section", {
				className: cx("card"),
				"aria-label": `Log for ${node.name}`,
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: cx("row"),
						children: [
							/* @__PURE__ */ jsx(NetworkBadge, { network: node.network }),
							/* @__PURE__ */ jsx("h2", {
								className: cx("h"),
								children: node.name
							}),
							/* @__PURE__ */ jsx("span", {
								className: node.state === "connected" ? cx("ok") : cx("muted"),
								children: node.state
							})
						]
					}),
					/* @__PURE__ */ jsxs("p", {
						className: `${cx("help")} ${cx("mono")}`,
						children: [
							node.host,
							":",
							node.port,
							node.self?.firmware ? ` · ${node.self.firmware}` : "",
							node.self?.model ? ` · ${node.self.model}` : "",
							node.self?.radio ? ` · ${node.self.radio}` : ""
						]
					}),
					/* @__PURE__ */ jsxs("p", {
						className: cx("help"),
						children: [
							node.contacts,
							node.contactCapacity !== void 0 && node.contactCapacity !== null ? ` of ${node.contactCapacity}` : "",
							" ",
							"contact",
							node.contacts === 1 ? "" : "s",
							" saved on the node",
							node.contactCapacity !== void 0 && node.contactCapacity !== null && node.contacts >= node.contactCapacity ? /* @__PURE__ */ jsx("span", {
								className: cx("warn"),
								children: " — full, so it can’t save new stations"
							}) : null,
							node.contactsHeardOnly > 0 ? `, ${node.contactsHeardOnly} heard but not saved` : "",
							" · ",
							node.channels,
							" ",
							"channel",
							node.channels === 1 ? "" : "s",
							node.identity ? ` · paired with ${node.identity.slice(0, 12)}…` : ""
						]
					}),
					node.detail && /* @__PURE__ */ jsx("p", {
						className: cx("help"),
						children: node.detail
					}),
					activity.length === 0 ? /* @__PURE__ */ jsx("p", {
						className: cx("help"),
						children: needle ? "Nothing in the log matches." : "Nothing logged yet."
					}) : /* @__PURE__ */ jsx("ol", {
						className: cx("log"),
						children: activity.slice().reverse().map((a, i) => /* @__PURE__ */ jsxs("li", {
							className: cx("log-line"),
							children: [
								/* @__PURE__ */ jsx("span", {
									className: `${cx("mono")} ${cx("muted")}`,
									children: time(a.at)
								}),
								/* @__PURE__ */ jsx("span", {
									className: `${cx("mono")} ${cx(levelClass[a.level] ?? "muted")}`,
									children: levelLabel[a.level] ?? "·"
								}),
								/* @__PURE__ */ jsx("span", { children: a.text })
							]
						}, `${a.at}-${i}`))
					})
				]
			}, node.id))
		]
	});
}
//#endregion
//#region src/Panel.tsx
/** Calls `load` now and every `ms`, ignoring results after unmount. */
function usePoll(load, ms, deps) {
	const [state, setState] = useState({ kind: "loading" });
	const loadRef = useRef(load);
	loadRef.current = load;
	const [tick, setTick] = useState(0);
	useEffect(() => {
		let alive = true;
		const run = async () => {
			try {
				const data = await loadRef.current();
				if (alive) setState({
					kind: "ready",
					data
				});
			} catch (err) {
				if (alive) setState({
					kind: "error",
					message: errorText(err)
				});
			}
		};
		run();
		const timer = setInterval(() => void run(), ms);
		return () => {
			alive = false;
			clearInterval(timer);
		};
	}, [
		ms,
		tick,
		...deps
	]);
	return [state, useCallback(() => setTick((t) => t + 1), [])];
}
function NetworkBadge({ network }) {
	return /* @__PURE__ */ jsx("span", {
		className: `${cx("badge")} ${cx(`badge--${network}`)}`,
		title: networkLabel[network],
		"aria-label": networkLabel[network],
		children: networkShort[network]
	});
}
function keepKeysLocal(e) {
	const tag = e.target.tagName;
	if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") e.stopPropagation();
}
function Panel({ client }) {
	const [tab, setTab] = useState("inbox");
	const [status, refreshStatus] = usePoll(() => client.status(), 2e3, [client]);
	const nodes = status.kind === "ready" ? status.data.nodes : [];
	const noNodes = status.kind === "ready" && nodes.length === 0;
	return /* @__PURE__ */ jsxs("div", {
		className: ROOT,
		onKeyDown: keepKeysLocal,
		children: [
			/* @__PURE__ */ jsx("div", {
				className: cx("tabs"),
				role: "tablist",
				"aria-label": "Mesh Messenger",
				children: [
					"inbox",
					"nodes",
					"settings",
					"debug"
				].map((t) => /* @__PURE__ */ jsx("button", {
					type: "button",
					role: "tab",
					"aria-selected": tab === t,
					className: `${cx("tab")} ${tab === t ? cx("tab--on") : ""}`,
					onClick: () => setTab(t),
					children: t === "inbox" ? "Inbox" : t === "nodes" ? "Nodes" : t === "settings" ? "Settings" : "Debug"
				}, t))
			}),
			status.kind === "loading" && /* @__PURE__ */ jsx("p", {
				className: cx("notice"),
				role: "status",
				children: "Loading Mesh Messenger…"
			}),
			status.kind === "error" && /* @__PURE__ */ jsxs("p", {
				className: `${cx("notice")} ${cx("notice--warn")}`,
				role: "alert",
				children: [
					"Can’t reach the Mesh Messenger backend (",
					status.message,
					"). Retrying."
				]
			}),
			status.kind === "ready" && /* @__PURE__ */ jsxs(Fragment, { children: [tab !== "settings" && tab !== "debug" && /* @__PURE__ */ jsx(NodeBar, {
				client,
				nodes,
				onChanged: refreshStatus
			}), noNodes && tab !== "settings" && tab !== "debug" ? /* @__PURE__ */ jsx("div", {
				className: cx("pane"),
				children: /* @__PURE__ */ jsxs("div", {
					className: cx("card"),
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: cx("h"),
							children: "Add your first node"
						}),
						/* @__PURE__ */ jsx("p", {
							className: cx("help"),
							children: "Zeus talks to a Meshtastic or MeshCore node on your network. Scan finds it for you — no IP address or router settings needed."
						}),
						/* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("button", {
							type: "button",
							className: `${cx("button")} ${cx("button--primary")}`,
							onClick: () => setTab("settings"),
							children: "Add node"
						}) })
					]
				})
			}) : tab === "inbox" ? /* @__PURE__ */ jsx(Inbox, {
				client,
				status: status.data
			}) : tab === "nodes" ? /* @__PURE__ */ jsx(Nodes, {
				client,
				nodes,
				onChanged: refreshStatus
			}) : tab === "debug" ? /* @__PURE__ */ jsx(Debug, { client }) : /* @__PURE__ */ jsx(Settings, {
				client,
				status: status.data,
				onChanged: refreshStatus
			})] })
		]
	});
}
function stateText(n) {
	switch (n.state) {
		case "connected": return "● connected";
		case "connecting": return "… connecting";
		case "searching": return "… looking for it";
		case "error": return "▲ problem";
		case "disabled": return "○ off";
		default: return "○ disconnected";
	}
}
function NodeBar({ client, nodes, onChanged }) {
	if (nodes.length === 0) return null;
	const moves = nodes.filter((n) => n.pendingMove);
	return /* @__PURE__ */ jsxs("div", { children: [
		/* @__PURE__ */ jsx("div", {
			className: cx("nodes"),
			"aria-label": "Mesh nodes",
			children: nodes.map((n) => /* @__PURE__ */ jsxs("span", {
				className: `${cx("node")} ${cx(`node--${n.state}`)}`,
				title: n.detail ?? void 0,
				children: [
					/* @__PURE__ */ jsx(NetworkBadge, { network: n.network }),
					/* @__PURE__ */ jsx("span", { children: n.name }),
					/* @__PURE__ */ jsx("span", {
						className: n.state === "connected" ? cx("ok") : n.state === "error" ? cx("warn") : cx("muted"),
						children: stateText(n)
					})
				]
			}, n.id))
		}),
		nodes.filter((n) => n.state === "error" && n.detail).map((n) => /* @__PURE__ */ jsxs("p", {
			className: `${cx("notice")} ${cx("notice--warn")}`,
			role: "status",
			children: [
				n.name,
				": ",
				n.detail
			]
		}, n.id)),
		moves.map((n) => /* @__PURE__ */ jsxs("div", {
			className: `${cx("notice")} ${cx("notice--warn")}`,
			role: "status",
			children: [/* @__PURE__ */ jsxs("span", { children: [
				n.name,
				" was found at ",
				/* @__PURE__ */ jsx("span", {
					className: cx("mono"),
					children: n.pendingMove
				}),
				". Passwords are saved for this node, so Zeus waits for you before switching.",
				" "
			] }), /* @__PURE__ */ jsxs("span", {
				className: cx("row"),
				style: { marginTop: 6 },
				children: [/* @__PURE__ */ jsx("button", {
					type: "button",
					className: `${cx("button")} ${cx("button--primary")}`,
					onClick: () => void client.acceptMove(n.id).then(onChanged),
					children: "Use new address"
				}), /* @__PURE__ */ jsx("button", {
					type: "button",
					className: cx("button"),
					onClick: () => void client.ignoreMove(n.id).then(onChanged),
					children: "Ignore"
				})]
			})]
		}, n.id))
	] });
}
//#endregion
//#region src/index.tsx
var PANEL_ID = "meshmessenger";
function register(api) {
	injectStyles();
	const client = createClient(api);
	const MeshMessengerPanel = () => /* @__PURE__ */ jsx(Panel, { client });
	api.registerPanel({
		id: PANEL_ID,
		component: MeshMessengerPanel
	});
}
//#endregion
export { PANEL_ID, register as default };
